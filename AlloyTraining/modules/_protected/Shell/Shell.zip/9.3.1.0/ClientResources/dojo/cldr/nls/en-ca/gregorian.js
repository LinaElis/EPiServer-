//>>built
define("dojo/cldr/nls/en-ca/gregorian",{"dateFormatItem-MMMMEd":"E, MMMM d","dateFormatItem-MMdd":"MM/dd","dateFormatItem-yyMMM":"MMM yy","dateFormatItem-MMMMd":"MMMM d"});
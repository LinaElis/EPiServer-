define("epi-cms/conversion/PropertyDateConverter", [ 
    "dojo/_base/declare",
    "dojo/date/locale"
    ],
    function (
        declare,
        locale
        ) {

        return declare(null, {
            // summary:
            //    Converts PropertyDate value to runtime Date accroding to epi/datetime rules
            //
            // tags:
            //    private

            sourceDataType: "epi.cms.propertydate",
            targetDataType: "runtimeType",

            registerDefaultConverters: function (/*Object*/registry) {
                // summary:
                //    Registers the type conversions that this class supports to the given registry.
                //
                // registry: Object
                //    The converter registry to add mappings to.
                registry.registerConverter(this.sourceDataType, this.targetDataType, this);
            },

            convert: function (/*String*/sourceDataType, /*String*/targetDataType, /*Object*/data) {
                // summary:
                //    Converts data between two types.
                //
                // sourceDataType: String
                //    The source data type.
                //
                // targetDataType: String
                //    The target data type.
                //
                // converter: Object
                //    The class that performs the actual conversion.
                // tags:
                //    public

                if (data && sourceDataType === this.sourceDataType && targetDataType === this.targetDataType) {
                    var value = new Date(data);

                    // Make sure that the converted value are the same the value which is handled by DateTimeTextBox
                    var localeString = locale.format(value, {});
                    return locale.parse(localeString, {});
                }

                return null;
            }
        });
    }
);